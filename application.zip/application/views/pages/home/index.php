<section class="content">
	<div class="container-fluid">
		<h1>Halaman Home</h1>
	</div>
</section>
